import UIKit

var greeting = "Hello, playground"

// Грузовик

enum Transmission {
    case auto, manual
}

enum EngineState {
    case on, off
}

enum DoorState {
    case open, closed
}

enum TankLevel {
    case full, empty
}

enum Trailer {
    case big, small
}

struct TrunkCar {
    var brand: String
    var trailer: Trailer
    var trunkCapacity: Int
    var trunkFilledCapacity: Int
    var engineCapacity: Int
    var spareWheel: Bool
    var engineState: EngineState
    var doorState: DoorState
    var tankLevel: TankLevel
    
    mutating func openDoor () {
        doorState = .open
    }

    mutating func closeDoor () {
        doorState = .closed
    }
    
    mutating func tankLevel(_ tankLevel: TankLevel ) {
        self.tankLevel = tankLevel
    }
    mutating func engineState(_ engineState: EngineState) {
        self.engineState = engineState
    }
}

// Легковая машина
struct SportCar {
    var brand: String
    var yearOfissue: Int
    var maxSpeed: Int
    var transmission: Transmission
    var engineState: EngineState
    var doorState: DoorState
    var parkingSensor: Bool
    var tankLevel: TankLevel
    
    mutating func doorState(_ doorState: DoorState) {
        self.doorState = doorState
    }
    
    mutating func fillTank() {
        tankLevel = .full
    }
    
    mutating func emptyTank() {
        tankLevel = .empty
    }
    
    mutating func engineOn() {
        engineState = .on
    }
    
    mutating func engineOff() {
        engineState = .off
    }
}

func printSportCar (car: SportCar) {       //Задаем принт в консоль для Легковой машины 
    print("---------")
    print("Марка: \(car.brand)")
    print("Год выпуска: \(car.yearOfissue) год")
    print("Максимальная скорость: \(car.maxSpeed) км/ч")
    print("Коробка передач: \(car.transmission == .auto ? "Автомат": "Механика")")
    print("Состояние двигателя: \(car.engineState == .on ? "включен" : "выключен")")
    print("Состояние дверей: \(car.doorState == .open ? "открыты" : "закрыты")")
    print("Парктроник: \(car.parkingSensor ? "имеется" : "отсутствует")")
    print("Уровень бензина в бензобаке: \(car.tankLevel == .full ? "заполнен" : "пустой" )")
}

func printTrunkCar (car: TrunkCar) {     //Задаем принт в консоль для грузовика
    print("---------")
    print("Марка: \(car.brand)")
    print("Размер прицепа: \(car.trailer == .big ? "большой" : "маленький")")
    print("Объем богажника: \(car.trunkCapacity)литров ")
    print("Заполненный объем багажника: \(car.trunkFilledCapacity)литров ")
    print("Объем двигателя: \(car.engineCapacity) см3 ")
    print("Наличие запасного колеса: \(car.spareWheel ? "имеется" : "отсутствует")")
    print("Состояние двигателя: \(car.engineState == .on ? "включен" : "выключен")")
    print("Состояние дверей: \(car.doorState  == .open ? "открыты" : "закрыты")")
    print("Уровень бензина в бензобаке: \(car.tankLevel == .full ? "заполнен" : "пустой" )")
}

// Возьмем 2 спортивные машины и изменим часть их свойств и выведем в консоль
var sportCar1 = SportCar(brand: "BMW M5", yearOfissue: 2018, maxSpeed: 330, transmission: .auto , engineState: .off, doorState: .closed, parkingSensor:true, tankLevel: .full)
sportCar1.yearOfissue = 2021
sportCar1.maxSpeed = 350                              //Меняем свойства 1 машины

var sportCar2 = SportCar (brand: "Audi RS6", yearOfissue: 2020, maxSpeed: 300, transmission: .auto, engineState: .on, doorState: .open, parkingSensor: false, tankLevel:.empty)
sportCar2.fillTank()
sportCar2.engineOn()                                  //Меняем свойства 2 машины
sportCar2.doorState(.closed)

printSportCar(car: sportCar1)
printSportCar(car: sportCar2)


//Возьмем 2 грузовые машини и изменим часть их свойств и выведем в консоль
var trunkCar1 = TrunkCar(brand: "Камаз", trailer: .big, trunkCapacity: 1000, trunkFilledCapacity: 500, engineCapacity: 3000, spareWheel: true, engineState: .on, doorState: .open, tankLevel: .full)

trunkCar1.engineState(.off)
trunkCar1.tankLevel(.full)

var trunkCar2 = TrunkCar (brand: "Volvo", trailer: .small, trunkCapacity: 579, trunkFilledCapacity: 450, engineCapacity: 2500, spareWheel: true, engineState: .on, doorState: .closed, tankLevel: .empty)
trunkCar2.openDoor()
trunkCar2.engineState(.off)

printTrunkCar(car: trunkCar1)
printTrunkCar(car: trunkCar2)
 

